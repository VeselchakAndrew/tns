--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.5 (Ubuntu 13.5-1.pgdg20.04+1)
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dc70328q6g3q8k;
--
-- Name: dc70328q6g3q8k; Type: DATABASE; Schema: -; Owner: hgtygshlmuyzop
--

CREATE DATABASE dc70328q6g3q8k WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE dc70328q6g3q8k OWNER TO hgtygshlmuyzop;

\connect dc70328q6g3q8k

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE TABLE public.companies (
    company_id integer NOT NULL,
    name character varying(255),
    department_id integer
);


ALTER TABLE public.companies OWNER TO hgtygshlmuyzop;

--
-- Name: companies_company_id_seq; Type: SEQUENCE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE SEQUENCE public.companies_company_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_company_id_seq OWNER TO hgtygshlmuyzop;

--
-- Name: companies_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hgtygshlmuyzop
--

ALTER SEQUENCE public.companies_company_id_seq OWNED BY public.companies.company_id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE TABLE public.departments (
    department_id integer NOT NULL,
    department_name character varying(255) NOT NULL,
    synchronize boolean DEFAULT false
);


ALTER TABLE public.departments OWNER TO hgtygshlmuyzop;

--
-- Name: departments_department_id_seq; Type: SEQUENCE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE SEQUENCE public.departments_department_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_department_id_seq OWNER TO hgtygshlmuyzop;

--
-- Name: departments_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hgtygshlmuyzop
--

ALTER SEQUENCE public.departments_department_id_seq OWNED BY public.departments.department_id;


--
-- Name: employee_roles; Type: TABLE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE TABLE public.employee_roles (
    role_id integer NOT NULL,
    role_name character varying(255) NOT NULL
);


ALTER TABLE public.employee_roles OWNER TO hgtygshlmuyzop;

--
-- Name: employee_role_id_seq; Type: SEQUENCE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE SEQUENCE public.employee_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_role_id_seq OWNER TO hgtygshlmuyzop;

--
-- Name: employee_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hgtygshlmuyzop
--

ALTER SEQUENCE public.employee_role_id_seq OWNED BY public.employee_roles.role_id;


--
-- Name: employee_salary_type; Type: TABLE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE TABLE public.employee_salary_type (
    salary_type_id integer NOT NULL,
    salary_type character varying(255) NOT NULL
);


ALTER TABLE public.employee_salary_type OWNER TO hgtygshlmuyzop;

--
-- Name: employee_salary_type_salary_type_id_seq; Type: SEQUENCE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE SEQUENCE public.employee_salary_type_salary_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_salary_type_salary_type_id_seq OWNER TO hgtygshlmuyzop;

--
-- Name: employee_salary_type_salary_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hgtygshlmuyzop
--

ALTER SEQUENCE public.employee_salary_type_salary_type_id_seq OWNED BY public.employee_salary_type.salary_type_id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    employee_firstname character varying(255) NOT NULL,
    employee_lastname character varying(255) NOT NULL,
    employee_role integer NOT NULL,
    employee_department_id integer NOT NULL,
    employee_company character varying(255) DEFAULT 'My Company'::character varying NOT NULL,
    preferred_start_working integer DEFAULT 0,
    work_from_home boolean DEFAULT false,
    salary_type integer DEFAULT 1
);


ALTER TABLE public.employees OWNER TO hgtygshlmuyzop;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: hgtygshlmuyzop
--

CREATE SEQUENCE public.employees_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_employee_id_seq OWNER TO hgtygshlmuyzop;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hgtygshlmuyzop
--

ALTER SEQUENCE public.employees_employee_id_seq OWNED BY public.employees.employee_id;


--
-- Name: companies company_id; Type: DEFAULT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.companies ALTER COLUMN company_id SET DEFAULT nextval('public.companies_company_id_seq'::regclass);


--
-- Name: departments department_id; Type: DEFAULT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.departments ALTER COLUMN department_id SET DEFAULT nextval('public.departments_department_id_seq'::regclass);


--
-- Name: employee_roles role_id; Type: DEFAULT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employee_roles ALTER COLUMN role_id SET DEFAULT nextval('public.employee_role_id_seq'::regclass);


--
-- Name: employee_salary_type salary_type_id; Type: DEFAULT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employee_salary_type ALTER COLUMN salary_type_id SET DEFAULT nextval('public.employee_salary_type_salary_type_id_seq'::regclass);


--
-- Name: employees employee_id; Type: DEFAULT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employees ALTER COLUMN employee_id SET DEFAULT nextval('public.employees_employee_id_seq'::regclass);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: hgtygshlmuyzop
--

COPY public.companies (company_id, name, department_id) FROM stdin;
\.
COPY public.companies (company_id, name, department_id) FROM '$$PATH$$/4026.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: hgtygshlmuyzop
--

COPY public.departments (department_id, department_name, synchronize) FROM stdin;
\.
COPY public.departments (department_id, department_name, synchronize) FROM '$$PATH$$/4024.dat';

--
-- Data for Name: employee_roles; Type: TABLE DATA; Schema: public; Owner: hgtygshlmuyzop
--

COPY public.employee_roles (role_id, role_name) FROM stdin;
\.
COPY public.employee_roles (role_id, role_name) FROM '$$PATH$$/4028.dat';

--
-- Data for Name: employee_salary_type; Type: TABLE DATA; Schema: public; Owner: hgtygshlmuyzop
--

COPY public.employee_salary_type (salary_type_id, salary_type) FROM stdin;
\.
COPY public.employee_salary_type (salary_type_id, salary_type) FROM '$$PATH$$/4029.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: hgtygshlmuyzop
--

COPY public.employees (employee_id, employee_firstname, employee_lastname, employee_role, employee_department_id, employee_company, preferred_start_working, work_from_home, salary_type) FROM stdin;
\.
COPY public.employees (employee_id, employee_firstname, employee_lastname, employee_role, employee_department_id, employee_company, preferred_start_working, work_from_home, salary_type) FROM '$$PATH$$/4022.dat';

--
-- Name: companies_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hgtygshlmuyzop
--

SELECT pg_catalog.setval('public.companies_company_id_seq', 1, false);


--
-- Name: departments_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hgtygshlmuyzop
--

SELECT pg_catalog.setval('public.departments_department_id_seq', 5, true);


--
-- Name: employee_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hgtygshlmuyzop
--

SELECT pg_catalog.setval('public.employee_role_id_seq', 4, true);


--
-- Name: employee_salary_type_salary_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hgtygshlmuyzop
--

SELECT pg_catalog.setval('public.employee_salary_type_salary_type_id_seq', 3, true);


--
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hgtygshlmuyzop
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 82, true);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (company_id);


--
-- Name: departments departments_department_name_key; Type: CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_department_name_key UNIQUE (department_name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_id);


--
-- Name: employee_roles employee_role_pk; Type: CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employee_roles
    ADD CONSTRAINT employee_role_pk PRIMARY KEY (role_id);


--
-- Name: employee_salary_type employee_salary_type_pk; Type: CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employee_salary_type
    ADD CONSTRAINT employee_salary_type_pk PRIMARY KEY (salary_type_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: employee_role_role_name_uindex; Type: INDEX; Schema: public; Owner: hgtygshlmuyzop
--

CREATE UNIQUE INDEX employee_role_role_name_uindex ON public.employee_roles USING btree (role_name);


--
-- Name: employee_salary_type_salary_type_id_uindex; Type: INDEX; Schema: public; Owner: hgtygshlmuyzop
--

CREATE UNIQUE INDEX employee_salary_type_salary_type_id_uindex ON public.employee_salary_type USING btree (salary_type_id);


--
-- Name: employee_salary_type_salary_type_uindex; Type: INDEX; Schema: public; Owner: hgtygshlmuyzop
--

CREATE UNIQUE INDEX employee_salary_type_salary_type_uindex ON public.employee_salary_type USING btree (salary_type);


--
-- Name: companies companies_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(department_id);


--
-- Name: employees employees_departments__fk; Type: FK CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_departments__fk FOREIGN KEY (employee_department_id) REFERENCES public.departments(department_id);


--
-- Name: employees employees_employee_salary_type__fk; Type: FK CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_salary_type__fk FOREIGN KEY (salary_type) REFERENCES public.employee_salary_type(salary_type_id);


--
-- Name: employees employees_role___fk; Type: FK CONSTRAINT; Schema: public; Owner: hgtygshlmuyzop
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_role___fk FOREIGN KEY (employee_role) REFERENCES public.employee_roles(role_id);


--
-- Name: DATABASE dc70328q6g3q8k; Type: ACL; Schema: -; Owner: hgtygshlmuyzop
--

REVOKE CONNECT,TEMPORARY ON DATABASE dc70328q6g3q8k FROM PUBLIC;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: hgtygshlmuyzop
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO hgtygshlmuyzop;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: LANGUAGE plpgsql; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON LANGUAGE plpgsql TO hgtygshlmuyzop;


--
-- PostgreSQL database dump complete
--

